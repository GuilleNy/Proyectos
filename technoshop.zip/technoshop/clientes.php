﻿<html>
   
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
     <title> TECHNOSHOP - Clientes </title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
 </head>
   
 <body>
   
    <div class="container ">
        <!--Aplicacion-->
		<div class="card border-success mb-3" style="max-width: 30rem;">
		<div class="card-header">TECHNOSHOP - Menú Clientes </div>
		<div class="card-body">
		
	<!-- INICIO DEL FORMULARIO -->
	<form action="" method="post">
		<B>Nombre Completo Cliente:</B>  <BR>
		<B>Fecha Nacimiento:</B>  <BR>
		<B>Email:</B>    <BR>
			  
		<BR><BR>
		
		<!--Formulario con enlaces -->
		<div>
			<input type="submit" value="Comprar Artículos" name="comprar" class="btn btn-warning disabled">
			<input type="submit" value="Consultar Pedidos" name="pedidos" class="btn btn-warning disabled">
			<input type="submit" value="Salir" name="salir" class="btn btn-warning disabled">
		</div>	
	</form>	
       
		
		  
	</div>  
	  
	  
     
   </body>
   
</html>


